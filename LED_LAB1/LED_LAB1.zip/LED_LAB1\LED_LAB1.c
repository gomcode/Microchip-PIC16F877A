#include <16F877A.h>
#fuses HS,NOPROTECT,NOBROWNOUT,NOWDT,NOPUT,NOCPD,NOLVP,NOWRT
#use delay(clock=20000000)

#byte PORTD = 0x08
#byte TRISD = 0x88	// Input or Output

#byte INTCON = 0x0B
#bit GIE = INTCON.7  //Global Interrupt Enable bit [24P]
#bit PEIE = INTCON.6  //Peripheral Interrupt Enable bit

/*

void main(void){
	TRISD = 0x00;  // Output
	PORTD = 0x00;	// clear

	while(1){

		// LED Blink - 1Hz
		PORTD = 0xff;
		delay_ms(500);
		PORTD = 0x00;
		delay_ms(500);

		// LED Blink - 2Hz
		PORTD = 0xff;
		delay_ms(0);
		PORTD = 0x00;
		delay_ms(
0);

		
	}	
}

*/

#int1
led_blink_1() {
	PORTD = 0xff;
	delay_ms(500);
	PORTD = 0x00;
}

void main(void) {

	TRISD = 0x00;  // Output
	PORTD = 0x00;	// clear

	GIE = 1;
	OEIE = 1;

	enable_interrupts(int1);
	enable_interrupts(global);
	
	while(1);
}